# OrcaDataPy

OrcaDataPy is the name of the respository and overall package name. To install into python, run: 
pip install git+https://github.com/amyhume/OrcaDataPy.git

You may need to change to pip3 depending on your version

In python, to import, run

import orca
